import canonicalCopy from '@remoteai/i18n/copy/client/connectionErrors';
export const CONNECTION_ERRORS = canonicalCopy;

export function socketConnectionError(code: number) {
  switch (code) {
    case 4001: return CONNECTION_ERRORS.authorization;
    case 4004: return CONNECTION_ERRORS.unavailable;
    case 4008: return CONNECTION_ERRORS.limit;
    case 1001: case 1011: case 1012: case 1013: return CONNECTION_ERRORS.server;
    default: return CONNECTION_ERRORS.network;
  }
}

export function authorizationError(error: unknown) {
  const status = error && typeof error === 'object' && 'status' in error ? error.status : undefined;
  const message = error instanceof Error ? error.message : error;
  // The H5 login layer predates status-bearing errors; recognize only its known login messages.
  if (['登录已过期，请重新登录', '请先登录', '请重新登录后连接电脑。'].includes(String(message))) {
    return CONNECTION_ERRORS.expired;
  }
  if (status === 401) return CONNECTION_ERRORS.expired;
  if (status === 403) return CONNECTION_ERRORS.authorization;
  if (typeof status === 'number' && status >= 500) return CONNECTION_ERRORS.server;
  return CONNECTION_ERRORS.network;
}

const GUI_ERRORS = new Map<string, string>([
  ['请先下载 Codex，即可开始对话。', CONNECTION_ERRORS.missingGui],
  ['Codex 暂时无法启动，请检查 Codex 配置后重试。', CONNECTION_ERRORS.startup],
  ['Codex 响应超时，请检查连接状态。', CONNECTION_ERRORS.guiTimeout],
  ['Codex 已断开连接，请重新连接后继续。', CONNECTION_ERRORS.guiDisconnected],
  ['暂时无法准备对话，请稍后重试。', CONNECTION_ERRORS.workspace],
  ['Codex 未能完成操作，请检查当前账户、模型和 Codex 配置。', CONNECTION_ERRORS.configuration],
  ['当前手机端暂不支持此操作。', CONNECTION_ERRORS.incompatible],
]);

/** Translate known desktop errors without sending paths or raw platform failures to the phone. */
export function guiConnectionError(error: unknown) {
  const message = error instanceof Error ? error.message : error;
  if (typeof message !== 'string') return CONNECTION_ERRORS.gui;
  if (Object.values(CONNECTION_ERRORS).some((known) => known === message)) return message;
  return GUI_ERRORS.get(message) ?? CONNECTION_ERRORS.gui;
}
