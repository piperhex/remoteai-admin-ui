import { Acknowledgements } from './acknowledgements';
import { ReliableDelivery, type DeliveryData } from './delivery';
import { Assembler } from './framing';
import { SendQueue } from './sendQueue';
import type { ConnectionMode, RpcMessage } from './protocol';
import type { TransferProgress } from './uploadProgress';

type Lane = 'ordered' | 'responses';
interface Stream {
  delivery: ReliableDelivery;
  outgoing: SendQueue;
  acknowledgements: Map<ConnectionMode, Acknowledgements>;
  waiters: Set<() => void>;
}

/** Events/commands retain order. Independent response fragments have their own window and acknowledgements. */
export class LinkDelivery {
  private readonly assembler = new Assembler(false);
  private readonly streams: Record<Lane, Stream>;
  private parallel = false;
  private closed = false;

  constructor(private readonly options: {
    send: (frame: DeliveryData, retry: boolean) => boolean;
    message: (message: RpcMessage) => void;
    mode: () => ConnectionMode;
  }) {
    this.streams = { ordered: this.create('ordered'), responses: this.create('responses') };
  }

  enableResponses() { this.parallel = true; }

  private create(lane: Lane): Stream {
    const delivery = new ReliableDelivery({
      unordered: lane === 'responses',
      send: (frame, retry) => this.options.send(this.envelope(lane, frame), retry),
      accept: (text, mode) => {
        const message = this.assembler.accept(text, mode);
        if (message && lane === 'responses' && message.kind !== 'response') throw new Error('Invalid response lane');
        if (message) this.options.message(message);
      },
    });
    const outgoing = new SendQueue({
      capacity: () => this.capacity(lane), mode: this.options.mode,
      acknowledgedResponses: true,
      prefix: `${lane}:`,
      send: (part, delivered) => delivery.enqueue(part, delivered),
    });
    return { delivery, outgoing, acknowledgements: new Map(), waiters: new Set() };
  }

  private envelope<T extends object>(lane: Lane, frame: T) {
    return lane === 'responses' ? { ...frame, lane } : frame;
  }

  send(message: RpcMessage, progress?: TransferProgress) {
    const lane = this.parallel && message.kind === 'response' ? 'responses' : 'ordered';
    return this.streams[lane].outgoing.send(message, progress);
  }

  accept(frame: Record<string, unknown>, reply: (frame: object) => void, mode: ConnectionMode) {
    if (frame.lane !== undefined && frame.lane !== 'responses') throw new Error('Invalid delivery lane');
    const lane = frame.lane === 'responses' ? 'responses' : 'ordered';
    const stream = this.streams[lane];
    let acknowledgements = stream.acknowledgements.get(mode);
    if (!acknowledgements) {
      acknowledgements = new Acknowledgements();
      stream.acknowledgements.set(mode, acknowledgements);
    }
    // A duplicate on one path must not replace a pending acknowledgement on the other path.
    stream.delivery.accept(frame, (ack) => acknowledgements.schedule(ack,
      (latest) => reply(this.envelope(lane, latest))), mode);
    if (!stream.delivery.full) this.release(stream);
  }

  flush(force = false) {
    for (const stream of Object.values(this.streams)) stream.delivery.flush(force);
  }

  setAvailable(available: boolean, now = Date.now()) {
    for (const stream of Object.values(this.streams)) stream.delivery.setAvailable(available, now);
  }

  private async capacity(lane: Lane) {
    const stream = this.streams[lane];
    while (!this.closed && stream.delivery.full) {
      await new Promise<void>((resolve) => stream.waiters.add(resolve));
    }
    if (this.closed) throw new Error('电脑已断开连接。');
  }

  private release(stream: Stream) {
    for (const resolve of stream.waiters) resolve();
    stream.waiters.clear();
  }

  clear() {
    this.closed = true;
    for (const stream of Object.values(this.streams)) {
      stream.outgoing.close();
      stream.delivery.clear();
      for (const acknowledgements of stream.acknowledgements.values()) acknowledgements.clear();
      stream.acknowledgements.clear();
      this.release(stream);
    }
    this.assembler.clear();
  }
}
